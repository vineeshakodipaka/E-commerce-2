// // src/Data.js
// const products = [
//   {
//     id: 1,
//     title: "Samsung Galaxy S7",
//     price: 700.0,
//     img: "https://res.cloudinary.com/drecbsopp/image/upload/v1627398399/samasung-galaxy-a51-8gb-8uh_tndbgv.jpg",
//     quantity: 1,
//   },
//   {
//     id: 2,
//     title: "iQOO 9 SE 5G",
//     price: 800.0,
//     img: "https://m.media-amazon.com/images/I/41YFUk64EzL._SX300_SY300_QL70_FMwebp_.jpg",
//     quantity: 1,
//   },
// ];

// export default products;
